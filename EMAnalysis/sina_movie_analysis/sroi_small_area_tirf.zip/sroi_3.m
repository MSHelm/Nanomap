function sroi_3

global movi rows cols A d c xx yy iii i bbb q s ijj 
 