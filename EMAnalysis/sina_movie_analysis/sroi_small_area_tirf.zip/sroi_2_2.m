function sroi_2

global list mapname b movi rows cols A i xx yy zz iii bbb q s ijj jjj r firstred  matrix counter xxes yyes backmatrix counter2 xxes2 yyes2 autos


set(gcf,'windowbuttonmotionfcn','sroi_3'); 


