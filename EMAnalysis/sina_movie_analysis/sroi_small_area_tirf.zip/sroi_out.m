function sroi_out;

close all;
